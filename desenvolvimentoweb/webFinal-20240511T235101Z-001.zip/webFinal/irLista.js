var criar_button = document.getElementById("criarLista");

criar_button.addEventListener("click", (e) => {
    e.preventDefault();
    location.href = 'criarLista.html'

});